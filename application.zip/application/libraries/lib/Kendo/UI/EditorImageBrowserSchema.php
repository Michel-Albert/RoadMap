<?php

namespace Kendo\UI;

class EditorImageBrowserSchema extends \Kendo\SerializableObject {
//>> Properties

//<< Properties
}

?>
