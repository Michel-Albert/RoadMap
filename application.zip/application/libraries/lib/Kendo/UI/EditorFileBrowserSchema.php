<?php

namespace Kendo\UI;

class EditorFileBrowserSchema extends \Kendo\SerializableObject {
//>> Properties

//<< Properties
}

?>
